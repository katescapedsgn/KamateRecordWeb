package com.example.kamateapp;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.webkit.WebView;
import android.webkit.WebViewClient;


public class myWebViewClient extends WebViewClient {

    private Activity activity = null;
    private static final int REQUEST_VIDEO_CAPTURE = 1;

    public myWebViewClient(Activity activity) {
        this.activity = activity;
    }

    @Override
    public boolean shouldOverrideUrlLoading(WebView webView, String url) {
        // webView.loadUrl(url); || app://signal_activity | //assets/index.html

        if(url.contains("works.kateafable.com/videorecord")) return false;

        // Otherwise, the link is not for a page on my site, so launch another Activity that handles URLs
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        activity.startActivity(intent);
        return true;
    }

}
